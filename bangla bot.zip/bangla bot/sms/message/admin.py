from django.contrib import admin
from message.models import Contact,qnat

# Register your models here.


admin.site.register(Contact)
admin.site.register(qnat)

